# Plot ad hoc mnist instances
from keras.datasets import mnist
import matplotlib.pyplot as plt
# load (downloaded if needed) the MNIST dataset
(X_train, y_train), (X_test, y_test) = mnist.load_data()
# plot 8 images as gray scale
plt.subplot(441)
plt.imshow(X_train[0], cmap=plt.get_cmap('gray_r'))
plt.subplot(442)
plt.imshow(X_train[1], cmap=plt.get_cmap('gray_r'))
plt.subplot(443)
plt.imshow(X_train[2], cmap=plt.get_cmap('gray_r'))
plt.subplot(444)
plt.imshow(X_train[3], cmap=plt.get_cmap('gray_r'))
plt.subplot(445)
plt.imshow(X_train[4], cmap=plt.get_cmap('gray_r'))
plt.subplot(446)
plt.imshow(X_train[5], cmap=plt.get_cmap('gray_r'))
plt.subplot(447)
plt.imshow(X_train[6], cmap=plt.get_cmap('gray_r'))
plt.subplot(448)
plt.imshow(X_train[7], cmap=plt.get_cmap('gray_r'))
# show the plot
plt.show()
