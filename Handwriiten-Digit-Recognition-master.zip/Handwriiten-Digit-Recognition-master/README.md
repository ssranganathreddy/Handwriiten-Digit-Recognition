# Handwriiten-Digit-Recognition
At first to run the code u need to install python
Run the following code and at same location the mnist dataset to be present.
You will get the desired results.
